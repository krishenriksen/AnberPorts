Put maps in this directory that you want to use only in worlds and tours. 
This keeps your world and tour maps separate from your normal maps so
your map list doesn't get too full.